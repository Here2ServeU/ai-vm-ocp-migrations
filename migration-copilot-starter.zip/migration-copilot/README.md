# AI Migration Copilot — starter kit

A watsonx Orchestrate agent that helps move VMware VMs to Red Hat OpenShift
Virtualization: **discover → assess → plan waves → run (with approval) → report**.

Everything runs in **demo mode** (sample data, no changes) until you add
real connections. That makes it safe to present.

## What's inside

| Path | What it does |
|---|---|
| `tools/vcenter_tools.py` | `discover_vms`, `readiness_summary` — read-only vCenter inventory + readiness rules |
| `tools/openshift_tools.py` | `create_migration_plan` (dry run by default), `start_migration` (needs a named approver), `migration_status`, `list_openshift_vms` |
| `agents/migration_copilot.yaml` | The agent: instructions, guardrails, tool list |
| `openshift/rbac.yaml` | Least-privilege service account for the Copilot |
| `scripts/setup.sh` | Imports connections, tools and agent into Orchestrate |
| `demo_local.py` | Rehearse on a laptop without Orchestrate |
| `docs/architecture.svg` | Architecture diagram |

## 1. Rehearse locally (5 minutes)

```bash
python3 -m venv venv && source venv/bin/activate
pip install ibm-watsonx-orchestrate -r requirements.txt
python demo_local.py
```

## 2. Run it in watsonx Orchestrate Developer Edition

Needs Docker (Rancher or Colima), about 16 GB RAM and 8 cores.

```bash
orchestrate server start -e .env        # your Orchestrate/watsonx entitlement settings
orchestrate env activate local
./scripts/setup.sh --demo               # demo mode, no real systems
orchestrate chat start                  # opens the chat UI
```

Pick a model your environment has (`orchestrate models list`) and set it as
`llm:` in `agents/migration_copilot.yaml`.

## 3. Connect a lab (real systems)

1. Install the **Migration Toolkit for Virtualization** operator on OpenShift and create
   a vSphere provider, a NetworkMap and a StorageMap (the MTV console does this).
2. `oc apply -f openshift/rbac.yaml`, then create a short-lived token.
3. Create a **read-only** vCenter account for discovery.
4. `cp .env.example .env.lab`, fill it in, `set -a; source .env.lab; set +a`
5. `./scripts/setup.sh`

Start with 5–10 test VMs.

## Guardrails built in

- Discovery is read-only. Plans are dry runs until you say otherwise.
- `start_migration` refuses to run without `approval_confirmed=true` and a named approver.
  The approver, time and change ticket are written onto the MTV Migration object
  and logged as an `AUDIT` line (send tool logs to your SIEM).
- Credentials live in Orchestrate connections, never in code.
- The OpenShift service account can only create MTV plans and migrations and read VMs.

## Readiness rules (edit in `assess()`)

| Result | Meaning |
|---|---|
| Ready | No issues found |
| Ready with prep | Snapshots, very large disks or very large VM |
| Blocked | RDM disk, shared multi-writer disk, PCI passthrough, or guest OS to review |
| Retire candidate | Powered off — confirm with the owner before moving it |

Always confirm guest OS support against Red Hat's current OpenShift
Virtualization documentation. These rules are a starting point, not a certification.

## Next steps

- Add an inventory/CMDB tool (owner, app, environment) to group waves by application.
- Add a report tool that writes a daily wave summary for leadership.
- Add watsonx.governance to track the model's decisions.
