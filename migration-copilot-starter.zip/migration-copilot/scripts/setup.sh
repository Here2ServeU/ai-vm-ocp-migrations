#!/usr/bin/env bash
# Import the Migration Copilot into your ACTIVE watsonx Orchestrate environment.
# Local first:  orchestrate server start -e .env   then   orchestrate env activate local
# Demo mode:    ./scripts/setup.sh --demo   (skips connections; tools use sample data)
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ "${1:-}" != "--demo" ]]; then
  orchestrate connections add -a vcenter || true
  orchestrate connections configure -a vcenter --env draft --type team --kind basic \
    --url "${VCENTER_URL:?set VCENTER_URL}"
  orchestrate connections set-credentials -a vcenter --env draft \
    -u "${VCENTER_USER:?}" -p "${VCENTER_PASSWORD:?}"

  orchestrate connections add -a openshift || true
  orchestrate connections configure -a openshift --env draft --type team --kind key_value
  orchestrate connections set-credentials -a openshift --env draft \
    -e "api_url=${OCP_API_URL:?}" -e "token=${OCP_TOKEN:?}" \
    -e "mtv_namespace=${MTV_NAMESPACE:-openshift-mtv}" \
    -e "source_provider=${MTV_SOURCE_PROVIDER:-vsphere}" \
    -e "destination_provider=host" \
    -e "network_map=${MTV_NETWORK_MAP:?}" -e "storage_map=${MTV_STORAGE_MAP:?}"
  APP_V="-a vcenter"; APP_O="-a openshift"
else
  APP_V=""; APP_O=""
fi

orchestrate tools import -k python -f tools/vcenter_tools.py   -r requirements.txt $APP_V
orchestrate tools import -k python -f tools/openshift_tools.py -r requirements.txt $APP_O
orchestrate agents import -f agents/migration_copilot.yaml
echo "Done. Try: orchestrate chat start"
